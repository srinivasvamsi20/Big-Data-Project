from google.cloud import bigquery

# Insert the new row into the dataset
insert_query = "INSERT INTO `your_project.your_dataset.your_table` (Brand, Model, AccelSec, Seats) VALUES ('Toyota', 'Fortuner', 7.7, 7)"

# Execute the insert query
query_job = client.query(insert_query)
query_job.result()  # Wait for the query to finish

# Retrieve the top 3 rows
select_query = 'SELECT * FROM `your_project.your_dataset.your_table` LIMIT 3'
query_job = client.query(select_query)
result = query_job.result()
for row in result:
    print(row)

print("Execution Time:", execution_time)
print("Memory Used:", memory_used, "bytes")
print("Query Execution Time:", query_execution_time)