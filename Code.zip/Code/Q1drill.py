import pyodbc
import time
import psutil

# Before executing the query
memory_before = psutil.virtual_memory().used
disk_io_before = psutil.disk_io_counters()
start_time = time.time()

query = 'SELECT Brand, Model, AccelSec, Seats FROM dfs.`/path/to/your/dataset/electric_vehicles.csv` WHERE Seats = 7'
cursor.execute(query)
result = cursor.fetchall()

# After executing the query
memory_after = psutil.virtual_memory().used
disk_io_after = psutil.disk_io_counters()
end_time = time.time()

# Calculate memory usage and disk I/O for the query
memory_used = memory_after - memory_before
read_bytes = disk_io_after.read_bytes - disk_io_before.read_bytes
write_bytes = disk_io_after.write_bytes - disk_io_before.write_bytes

# Execution time
execution_time = end_time - start_time

print("Execution Time:", execution_time)
print("Memory Used:", memory_used, "bytes")
print("Query Execution Time:", query_execution_time)

for row in result:
    print(row)
